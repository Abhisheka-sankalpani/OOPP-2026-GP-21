import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class StudentForm extends JFrame {
    private JTextField txtName, txtId, txtEmail, txtPhone, txtDob, txtDept, txtCourse, txtGpa, txtAddress;
    private JRadioButton rbMale, rbFemale, rbOther;
    private ButtonGroup genderGroup;
    private JComboBox<String> cbYear;

    public StudentForm() {
        setTitle("Student Information Form");
        setSize(450, 580);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel mainPanel = new JPanel(new GridLayout(12, 2, 8, 8));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        mainPanel.add(new JLabel("Student Name:"));
        txtName = new JTextField();
        mainPanel.add(txtName);

        mainPanel.add(new JLabel("Student ID:"));
        txtId = new JTextField();
        mainPanel.add(txtId);

        mainPanel.add(new JLabel("Email:"));
        txtEmail = new JTextField();
        mainPanel.add(txtEmail);

        mainPanel.add(new JLabel("Phone Number:"));
        txtPhone = new JTextField();
        mainPanel.add(txtPhone);

        mainPanel.add(new JLabel("Date of Birth:"));
        txtDob = new JTextField();
        mainPanel.add(txtDob);

        mainPanel.add(new JLabel("Gender:"));
        JPanel genderPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        rbMale = new JRadioButton("Male");
        rbFemale = new JRadioButton("Female");
        rbOther = new JRadioButton("Other");
        genderGroup = new ButtonGroup();
        genderGroup.add(rbMale);
        genderGroup.add(rbFemale);
        genderGroup.add(rbOther);
        genderPanel.add(rbMale);
        genderPanel.add(rbFemale);
        genderPanel.add(rbOther);
        mainPanel.add(genderPanel);

        mainPanel.add(new JLabel("Department:"));
        txtDept = new JTextField();
        mainPanel.add(txtDept);

        mainPanel.add(new JLabel("Course:"));
        txtCourse = new JTextField();
        mainPanel.add(txtCourse);

        mainPanel.add(new JLabel("Year of Study:"));
        String[] years = {"Select Year", "1st Year", "2nd Year", "3rd Year", "4th Year"};
        cbYear = new JComboBox<>(years);
        mainPanel.add(cbYear);

        mainPanel.add(new JLabel("GPA:"));
        txtGpa = new JTextField();
        mainPanel.add(txtGpa);

        mainPanel.add(new JLabel("Address:"));
        txtAddress = new JTextField();
        mainPanel.add(txtAddress);

        JButton btnSubmit = new JButton("Submit");
        JPanel btnPanel = new JPanel();
        btnPanel.add(btnSubmit);

        add(mainPanel, BorderLayout.CENTER);
        add(btnPanel, BorderLayout.SOUTH);

        btnSubmit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                validateAndSubmit();
            }
        });
    }

    private void validateAndSubmit() {
        String name = txtName.getText().trim();
        String id = txtId.getText().trim();
        String email = txtEmail.getText().trim();
        String phone = txtPhone.getText().trim();
        String dob = txtDob.getText().trim();
        String dept = txtDept.getText().trim();
        String course = txtCourse.getText().trim();
        String gpa = txtGpa.getText().trim();
        String address = txtAddress.getText().trim();

        String gender = "";
        if (rbMale.isSelected()) gender = "Male";
        else if (rbFemale.isSelected()) gender = "Female";
        else if (rbOther.isSelected()) gender = "Other";

        String year = (cbYear.getSelectedIndex() > 0) ? cbYear.getSelectedItem().toString() : "";

        if (name.isEmpty() || id.isEmpty() || email.isEmpty() || phone.isEmpty() ||
                dob.isEmpty() || gender.isEmpty() || dept.isEmpty() || course.isEmpty() ||
                year.isEmpty() || gpa.isEmpty() || address.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "You need to fill out all the data",
                    "Warning",
                    JOptionPane.WARNING_MESSAGE
            );
        } else {
            String details = String.format(
                    "Student Details:\n\n" +
                            "Name: %s\n" +
                            "ID: %s\n" +
                            "Email: %s\n" +
                            "Phone: %s\n" +
                            "DOB: %s\n" +
                            "Gender: %s\n" +
                            "Department: %s\n" +
                            "Course: %s\n" +
                            "Year: %s\n" +
                            "GPA: %s\n" +
                            "Address: %s",
                    name, id, email, phone, dob, gender, dept, course, year, gpa, address
            );

            JOptionPane.showMessageDialog(
                    this,
                    details,
                    "Submitted Information",
                    JOptionPane.INFORMATION_MESSAGE
            );
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new StudentForm().setVisible(true);
        });
    }
}
