import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class BMICalculatorApp extends JFrame {
    private JTextField weightField, heightField;
    private JRadioButton metricBtn, englishBtn;
    private JLabel resultLabel, categoryLabel;
    private CardLayout cardLayout;
    private JPanel mainPanel;

    public BMICalculatorApp() {
        setTitle("BMI Calculator - Group 19");
        setSize(420, 520);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        mainPanel.add(createWelcomePanel(), "Welcome");
        mainPanel.add(createInputPanel(), "Input");
        mainPanel.add(createResultPanel(), "Result");

        add(mainPanel);
        cardLayout.show(mainPanel, "Welcome"); // display Welcome
        setVisible(true);
    }

    private JPanel createWelcomePanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(240, 248, 255));

        JLabel title = new JLabel("<html><center><font size='6' color='#1e88e5'>Welcome To</font><br>" +
                "<font size='8' color='#1565c0'><b>BMI CALCULATOR</b></font></center></html>");
        title.setHorizontalAlignment(SwingConstants.CENTER);

        JButton startBtn = new JButton("Start Calculation");
        startBtn.setFont(new Font("Arial", Font.BOLD, 16));
        startBtn.setBackground(new Color(30, 136, 229));
        startBtn.setForeground(Color.WHITE);
        startBtn.addActionListener(e -> cardLayout.show(mainPanel, "Input"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(30, 20, 30, 20);
        panel.add(title, gbc);

        gbc.gridy = 1;
        gbc.insets = new Insets(10, 20, 10, 20);
        panel.add(startBtn, gbc);

        return panel;
    }

    private JPanel createInputPanel() {
        JPanel panel = new JPanel(null);
        panel.setBorder(BorderFactory.createTitledBorder("Enter Your Details"));

        // Weight
        JLabel wLabel = new JLabel("Weight:");
        wLabel.setBounds(40, 40, 100, 25);
        weightField = new JTextField();
        weightField.setBounds(40, 65, 320, 30);

        // Height
        JLabel hLabel = new JLabel("Height:");
        hLabel.setBounds(40, 110, 100, 25);
        heightField = new JTextField();
        heightField.setBounds(40, 135, 320, 30);

        // Unit
        JLabel unitLabel = new JLabel("Select Unit System:");
        unitLabel.setBounds(40, 185, 200, 25);
        metricBtn = new JRadioButton("Metric (kg & cm)", true);
        englishBtn = new JRadioButton("English (lb & inches)");
        ButtonGroup group = new ButtonGroup();
        group.add(metricBtn);
        group.add(englishBtn);
        metricBtn.setBounds(40, 215, 180, 25);
        englishBtn.setBounds(40, 245, 180, 25);

        // Calculate Button
        JButton calcBtn = new JButton("Calculate BMI");
        calcBtn.setBounds(40, 310, 320, 40);
        calcBtn.setFont(new Font("Arial", Font.BOLD, 14));
        calcBtn.setBackground(new Color(76, 175, 80));
        calcBtn.setForeground(Color.WHITE);
        calcBtn.addActionListener(new CalculateAction());

        // Exit Button for Input Screen
        JButton exitBtn = new JButton("Exit");
        exitBtn.setBounds(40, 365, 320, 40);
        exitBtn.setFont(new Font("Arial", Font.BOLD, 14));
        exitBtn.setBackground(new Color(211, 47, 47));
        exitBtn.setForeground(Color.WHITE);
        exitBtn.addActionListener(e -> System.exit(0));

        panel.add(wLabel);
        panel.add(weightField);
        panel.add(hLabel);
        panel.add(heightField);
        panel.add(unitLabel);
        panel.add(metricBtn);
        panel.add(englishBtn);
        panel.add(calcBtn);
        panel.add(exitBtn);

        return panel;
    }

    private JPanel createResultPanel() {
        JPanel panel = new JPanel(null);
        panel.setBackground(new Color(240, 248, 255));

        JLabel resTitle = new JLabel("Your BMI Result", SwingConstants.CENTER);
        resTitle.setFont(new Font("Arial", Font.BOLD, 22));
        resTitle.setBounds(40, 20, 320, 30);

        resultLabel = new JLabel("Your BMI is : --", SwingConstants.LEFT);
        resultLabel.setFont(new Font("Arial", Font.BOLD, 18));
        resultLabel.setBounds(50, 70, 300, 30);

        categoryLabel = new JLabel("Category : --", SwingConstants.LEFT);
        categoryLabel.setFont(new Font("Arial", Font.BOLD, 18));
        categoryLabel.setBounds(50, 105, 300, 30);

        JTextArea instructions = new JTextArea(
                "BMI Categories:\n" +
                        "• Underweight : < 18.5\n" +
                        "• Normal weight : 18.5 – 24.9\n" +
                        "• Overweight : 25 – 29.9\n" +
                        "• Obese : 30 or greater"
        );
        instructions.setBounds(40, 160, 320, 110);
        instructions.setEditable(false);
        instructions.setLineWrap(true);
        instructions.setWrapStyleWord(true);
        instructions.setBackground(panel.getBackground());
        instructions.setFont(new Font("Arial", Font.PLAIN, 14));

        // Recalculate Button
        JButton reCalcBtn = new JButton("Calculate Again");
        reCalcBtn.setBounds(40, 300, 320, 40);
        reCalcBtn.setFont(new Font("Arial", Font.BOLD, 14));
        reCalcBtn.setBackground(new Color(33, 150, 243));
        reCalcBtn.setForeground(Color.WHITE);
        reCalcBtn.addActionListener(e -> {
            weightField.setText("");
            heightField.setText("");
            cardLayout.show(mainPanel, "Input");
        });

        // Exit Button for Results Screen
        JButton exitBtn2 = new JButton("Exit Application");
        exitBtn2.setBounds(40, 355, 320, 40);
        exitBtn2.setFont(new Font("Arial", Font.BOLD, 14));
        exitBtn2.setBackground(new Color(211, 47, 47));
        exitBtn2.setForeground(Color.WHITE);
        exitBtn2.addActionListener(e -> System.exit(0));

        panel.add(resTitle);
        panel.add(resultLabel);
        panel.add(categoryLabel);
        panel.add(instructions);
        panel.add(reCalcBtn);
        panel.add(exitBtn2);

        return panel;
    }

    private class CalculateAction implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            try {
                double weight = Double.parseDouble(weightField.getText().trim());
                double height = Double.parseDouble(heightField.getText().trim());

                if (weight <= 0 || height <= 0) {
                    JOptionPane.showMessageDialog(null, "Values must be greater than zero!", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                double bmi;
                if (metricBtn.isSelected()) {
                    // weight (kg) / [height (m)]²
                    bmi = weight / Math.pow(height / 100.0, 2);
                } else {
                    // 703 * weight (lb) / [height (in)]²
                    bmi = (weight / Math.pow(height, 2)) * 703.0;
                }

                String category;
                if (bmi < 18.5) {
                    category = "Underweight";
                } else if (bmi >= 18.5 && bmi < 25.0) {
                    category = "Normal weight";
                } else if (bmi >= 25.0 && bmi < 30.0) {
                    category = "Overweight";
                } else {
                    category = "Obese";
                }

                resultLabel.setText(String.format("Your BMI is : %.1f", bmi));
                categoryLabel.setText("Category : " + category);
                cardLayout.show(mainPanel, "Result");

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Please enter valid numbers for weight and height!", "Input Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new BMICalculatorApp());
    }
}
