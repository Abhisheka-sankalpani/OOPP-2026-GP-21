import javax.swing.*;
import java.awt.*;

public class BMICalculator extends JFrame {
    private JTextField weightField = new JTextField(10), heightField = new JTextField(10);
    private JRadioButton metricBtn = new JRadioButton("Metric (kg, cm)", true), englishBtn = new JRadioButton("English (lb, in)");
    private JLabel resultLabel = new JLabel("Your BMI: --", SwingConstants.CENTER), categoryLabel = new JLabel("Category: --", SwingConstants.CENTER);
    private CardLayout cardLayout = new CardLayout();
    private JPanel mainPanel = new JPanel(cardLayout);

    public BMICalculator() {
        setTitle("BMI Calculator");
        setSize(360, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // --- PAGE 1: INPUT PAGE ---
        JPanel p1 = new JPanel(new GridLayout(8, 1, 5, 5));
        p1.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        ButtonGroup bg = new ButtonGroup(); bg.add(metricBtn); bg.add(englishBtn);
        p1.add(metricBtn); p1.add(englishBtn);
        p1.add(new JLabel("Weight:")); p1.add(weightField);
        p1.add(new JLabel("Height:")); p1.add(heightField);
        JButton calcBtn = new JButton("Calculate BMI");
        calcBtn.addActionListener(e -> calculateBMI());
        p1.add(new JLabel("")); p1.add(calcBtn);

        // --- PAGE 2: RESULT PAGE ---
        JPanel p2 = new JPanel(new BorderLayout(10, 20));
        p2.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JPanel resPanel = new JPanel(new GridLayout(2, 1));
        resultLabel.setFont(new Font("Arial", Font.BOLD, 16)); categoryLabel.setFont(new Font("Arial", Font.BOLD, 16));
        resPanel.add(resultLabel); resPanel.add(categoryLabel);
        p2.add(resPanel, BorderLayout.NORTH);


        JLabel infoLabel = new JLabel("<html><center><b>BMI Categories:</b><br><br>" +
                "• Underweight : &lt; 18.5<br>" +
                "• Normal weight : 18.5 – 24.9<br>" +
                "• Overweight : 25 – 29.9<br>" +
                "• Obese : 30 or greater</center></html>", SwingConstants.CENTER);
        infoLabel.setFont(new Font("Arial", Font.PLAIN, 13));
        p2.add(infoLabel, BorderLayout.CENTER);

        JPanel btnPanel = new JPanel(new GridLayout(2, 1, 5, 5));
        JButton reCalcBtn = new JButton("Calculate Again");
        reCalcBtn.addActionListener(e -> { weightField.setText(""); heightField.setText(""); cardLayout.show(mainPanel, "P1"); });
        JButton exitBtn = new JButton("Exit Application");
        exitBtn.addActionListener(e -> System.exit(0));
        btnPanel.add(reCalcBtn); btnPanel.add(exitBtn);
        p2.add(btnPanel, BorderLayout.SOUTH);

        mainPanel.add(p1, "P1"); mainPanel.add(p2, "P2");
        add(mainPanel);
        setVisible(true);
    }

    private void calculateBMI() {
        try {
            double w = Double.parseDouble(weightField.getText().trim());
            double h = Double.parseDouble(heightField.getText().trim());
            double bmi = metricBtn.isSelected() ? w / Math.pow(h / 100.0, 2) : 703 * (w / Math.pow(h, 2));

            String cat = (bmi < 18.5) ? "Underweight" : (bmi < 25.0) ? "Normal weight" : (bmi < 30.0) ? "Overweight" : "Obese";
            resultLabel.setText(String.format("Your BMI: %.1f", bmi));
            categoryLabel.setText("Category: " + cat);
            cardLayout.show(mainPanel, "P2");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) { SwingUtilities.invokeLater(BMICalculator::new); }
}
