import javax.swing.*;
import java.awt.*;

public class BMICalculatorApp extends JFrame {
    private final JTextField weightField = new JTextField(), heightField = new JTextField();
    private final JRadioButton metricRadio = new JRadioButton("Metric (kg & cm)", true);
    private final JRadioButton englishRadio = new JRadioButton("English (lb & in)");
    private final JLabel resultLabel = new JLabel("Your BMI is : --", SwingConstants.CENTER);
    private final JLabel statusLabel = new JLabel("Status : --", SwingConstants.CENTER);
    private final CardLayout cardLayout = new CardLayout();
    private final JPanel mainPanel = new JPanel(cardLayout);

    public BMICalculatorApp() {
        setTitle("BMI Calculator - Group 21");
        setSize(400, 430);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        mainPanel.add(createInputScreen(), "Input");
        mainPanel.add(createResultScreen(), "Result");
        add(mainPanel);
        setVisible(true);
    }

    private JPanel createInputScreen() {
        JPanel panel = new JPanel(null);
        panel.setBorder(BorderFactory.createTitledBorder("Enter Your Details"));

        String[] labels = {"Weight:", "Height:", "Select Value Units:"};
        int[] yPositions = {30, 110, 190};
        for (int i = 0; i < 3; i++) {
            JLabel label = new JLabel(labels[i]);
            label.setBounds(40, yPositions[i], 150, 25);
            panel.add(label);
        }

        weightField.setBounds(40, 60, 320, 35);
        heightField.setBounds(40, 140, 320, 35);
        metricRadio.setBounds(40, 220, 150, 25);
        englishRadio.setBounds(200, 220, 150, 25);

        ButtonGroup group = new ButtonGroup();
        group.add(metricRadio); group.add(englishRadio);

        JButton calcBtn = new JButton("Calculate BMI");
        calcBtn.setBounds(40, 280, 320, 45);
        calcBtn.setBackground(new Color(77, 193, 77));
        calcBtn.setForeground(Color.WHITE);
        calcBtn.addActionListener(e -> calculateBMI());

        panel.add(weightField); panel.add(heightField); panel.add(metricRadio); panel.add(englishRadio); panel.add(calcBtn);
        return panel;
    }

    private JPanel createResultScreen() {
        JPanel panel = new JPanel(null);
        panel.setBackground(new Color(240, 245, 250));

        resultLabel.setBounds(40, 30, 320, 30); resultLabel.setFont(new Font("Arial", Font.BOLD, 18));
        statusLabel.setBounds(40, 70, 320, 30); statusLabel.setFont(new Font("Arial", Font.BOLD, 18));

        JTextArea guide = new JTextArea("BMI Reference Categories:\n• Underweight : less than 18.5\n• Normal : Between 18.5 and 24.9\n• Overweight : Between 25 and 29.9\n• Obese : 30 or greater");
        guide.setBounds(40, 120, 320, 110);
        guide.setEditable(false);
        guide.setBackground(panel.getBackground());

        JButton backBtn = new JButton("Recalculate"); backBtn.setBounds(40, 260, 150, 40);
        backBtn.addActionListener(e -> { weightField.setText(""); heightField.setText(""); cardLayout.show(mainPanel, "Input"); });

        JButton exitBtn = new JButton("Exit"); exitBtn.setBounds(210, 260, 150, 40);
        exitBtn.addActionListener(e -> System.exit(0));

        panel.add(resultLabel); panel.add(statusLabel); panel.add(guide); panel.add(backBtn); panel.add(exitBtn);
        return panel;
    }

    private void calculateBMI() {
        try {
            double weight = Double.parseDouble(weightField.getText().trim());
            double height = Double.parseDouble(heightField.getText().trim());
            if (weight <= 0 || height <= 0) throw new Exception();

            double bmi = metricRadio.isSelected() ? weight / Math.pow(height / 100.0, 2) : 703 * (weight / Math.pow(height, 2));
            String status = bmi < 18.5 ? "Underweight" : bmi < 25.0 ? "Normal weight" : bmi < 30.0 ? "Overweight" : "Obese";

            resultLabel.setText(String.format("BMI Value : %.1f", bmi));
            statusLabel.setText("Status : " + status);
            cardLayout.show(mainPanel, "Result");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(BMICalculatorApp::new);
    }
}
