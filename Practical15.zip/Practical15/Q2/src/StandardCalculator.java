import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class StandardCalculator extends JFrame implements ActionListener {
    private JTextField display;
    private double num1 = 0, num2 = 0, result = 0;
    private char operator = '\0';
    private List<String> history = new ArrayList<>();

    public StandardCalculator() {
        setTitle("Calculator");
        setSize(320, 420);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        display = new JTextField();
        display.setFont(new Font("Arial", Font.BOLD, 22));
        display.setHorizontalAlignment(JTextField.RIGHT);
        display.setEditable(false);
        add(display, BorderLayout.NORTH);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 4, 5, 5));

        String[] buttons = {
                "7", "8", "9", "/",
                "4", "5", "6", "*",
                "1", "2", "3", "-",
                "0", ".", "=", "+",
                "C", "Hist", "", ""
        };

        for (String text : buttons) {
            if (text.isEmpty()) {
                panel.add(new JLabel(""));
            } else {
                JButton btn = new JButton(text);
                btn.setFont(new Font("Arial", Font.BOLD, 16));
                btn.addActionListener(this);
                panel.add(btn);
            }
        }

        add(panel, BorderLayout.CENTER);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();

        if ((command.charAt(0) >= '0' && command.charAt(0) <= '9') || command.equals(".")) {
            display.setText(display.getText() + command);
        } else if (command.equals("C")) {
            display.setText("");
            num1 = num2 = result = 0;
            operator = '\0';
        } else if (command.equals("Hist")) {
            showHistory();
        } else if (command.equals("=")) {
            if (!display.getText().isEmpty() && operator != '\0') {
                num2 = Double.parseDouble(display.getText());
                boolean valid = true;

                switch (operator) {
                    case '+': result = num1 + num2; break;
                    case '-': result = num1 - num2; break;
                    case '*': result = num1 * num2; break;
                    case '/':
                        if (num2 == 0) {
                            JOptionPane.showMessageDialog(this, "Cannot divide by zero");
                            valid = false;
                        } else {
                            result = num1 / num2;
                        }
                        break;
                }

                if (valid) {
                    String record = num1 + " " + operator + " " + num2 + " = " + result;
                    addHistory(record);
                    display.setText(String.valueOf(result));
                    operator = '\0';
                }
            }
        } else {
            if (!display.getText().isEmpty()) {
                num1 = Double.parseDouble(display.getText());
                operator = command.charAt(0);
                display.setText("");
            }
        }
    }

    private void addHistory(String record) {
        if (history.size() >= 10) {
            history.remove(0); // Maintain maximum 10 elements
        }
        history.add(record);
    }

    private void showHistory() {
        if (history.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No history available.", "Calculation History", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        StringBuilder sb = new StringBuilder("Last 10 Calculations:\n\n");
        for (int i = 0; i < history.size(); i++) {
            sb.append(i + 1).append(". ").append(history.get(i)).append("\n");
        }

        JOptionPane.showMessageDialog(this, sb.toString(), "Calculation History", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new StandardCalculator().setVisible(true);
        });
    }
}
