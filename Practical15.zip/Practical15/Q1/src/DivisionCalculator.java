import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DivisionCalculator extends JFrame {
    private JTextField txtNum1;
    private JTextField txtNum2;
    private JLabel lblResultValue;
    private JButton btnDivide;

    public DivisionCalculator() {
        setTitle("Division Calculator");
        setSize(320, 220);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        JLabel lblNum1 = new JLabel("Number 1 :");
        lblNum1.setBounds(30, 20, 80, 25);
        add(lblNum1);

        txtNum1 = new JTextField();
        txtNum1.setBounds(110, 20, 60, 25);
        add(txtNum1);

        JLabel lblResultHeader = new JLabel("Result");
        lblResultHeader.setBounds(190, 20, 80, 25);
        add(lblResultHeader);

        JLabel lblNum2 = new JLabel("Number 2 :");
        lblNum2.setBounds(30, 55, 80, 25);
        add(lblNum2);

        txtNum2 = new JTextField();
        txtNum2.setBounds(110, 55, 60, 25);
        add(txtNum2);

        lblResultValue = new JLabel("");
        lblResultValue.setBounds(190, 55, 80, 25);
        add(lblResultValue);

        btnDivide = new JButton("Divide");
        btnDivide.setBounds(70, 110, 90, 30);
        add(btnDivide);

        btnDivide.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    double num1 = Double.parseDouble(txtNum1.getText().trim());
                    double num2 = Double.parseDouble(txtNum2.getText().trim());

                    if (num2 == 0) {
                        lblResultValue.setText("");
                        JOptionPane.showMessageDialog(
                                DivisionCalculator.this,
                                "You can't enter 0 for second number",
                                "Message",
                                JOptionPane.INFORMATION_MESSAGE
                        );
                    } else {
                        double result = num1 / num2;
                        lblResultValue.setText(String.valueOf(result));
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(
                            DivisionCalculator.this,
                            "Please enter valid numeric values.",
                            "Input Error",
                            JOptionPane.ERROR_MESSAGE
                    );
                }
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new DivisionCalculator().setVisible(true);
        });
    }
}
