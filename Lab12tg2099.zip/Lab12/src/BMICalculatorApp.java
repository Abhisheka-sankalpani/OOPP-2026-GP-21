import javax.swing.*;
import java.awt.*;

public class BMICalculatorApp extends JFrame {
    private JTextField wTxt, hTxt;
    private JRadioButton rMetric, rEnglish;
    private JLabel lblResult, lblCat;
    private JPanel inputPanel, resultPanel;

    public BMICalculatorApp() {
        setTitle("BMI Calculator");
        setSize(380, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        setLayout(null);

        // PAGE 1: INPUT SCREEN
        inputPanel = new JPanel(null);
        inputPanel.setBounds(0, 0, 380, 500);

        JLabel wLabel = new JLabel("Weight :"); wLabel.setBounds(40, 30, 100, 25);
        wTxt = new JTextField(); wTxt.setBounds(40, 60, 280, 30);

        JLabel hLabel = new JLabel("Height :"); hLabel.setBounds(40, 110, 100, 25);
        hTxt = new JTextField(); hTxt.setBounds(40, 140, 280, 30);

        rMetric = new JRadioButton("Metric (kg, cm)", true); rMetric.setBounds(40, 190, 140, 25);
        rEnglish = new JRadioButton("English (lb, in)"); rEnglish.setBounds(180, 190, 140, 25);
        ButtonGroup bg = new ButtonGroup(); bg.add(rMetric); bg.add(rEnglish);

        JButton btnCalc = new JButton("Calculate BMI");
        btnCalc.setBounds(40, 240, 280, 40);
        btnCalc.setBackground(Color.LIGHT_GRAY); // Ash Colour
        btnCalc.addActionListener(e -> calculateBMI());

        inputPanel.add(wLabel); inputPanel.add(wTxt); inputPanel.add(hLabel); inputPanel.add(hTxt);
        inputPanel.add(rMetric); inputPanel.add(rEnglish); inputPanel.add(btnCalc);
        add(inputPanel);

        // PAGE 2: RESULT SCREEN
        resultPanel = new JPanel(null);
        resultPanel.setBounds(0, 0, 380, 500);
        resultPanel.setVisible(false);

        lblResult = new JLabel("BMI : --", SwingConstants.CENTER); lblResult.setBounds(40, 30, 280, 30);
        lblResult.setFont(new Font("Arial", Font.BOLD, 16));

        lblCat = new JLabel("Category : --", SwingConstants.CENTER); lblCat.setBounds(40, 70, 280, 30);
        lblCat.setFont(new Font("Arial", Font.BOLD, 16));

        JTextArea info = new JTextArea("BMI Status:\n- Underweight: < 18.5\n- Normal: 18.5 - 24.9\n- Overweight: 25 - 29.9\n- Obese: >= 30");
        info.setBounds(40, 120, 280, 90); info.setEditable(false); info.setBackground(getBackground());


        JButton btnRetry = new JButton("Calculate Again");
        btnRetry.setBounds(40, 230, 280, 40);
        btnRetry.setBackground(Color.LIGHT_GRAY); // Ash Colour
        btnRetry.addActionListener(e -> { wTxt.setText(""); hTxt.setText(""); resultPanel.setVisible(false); inputPanel.setVisible(true); });

        JButton btnExit = new JButton("Exit Application");
        btnExit.setBounds(40, 285, 280, 40);
        btnExit.setBackground(Color.LIGHT_GRAY); // Ash Colour
        btnExit.addActionListener(e -> System.exit(0));

        resultPanel.add(lblResult); resultPanel.add(lblCat); resultPanel.add(info);
        resultPanel.add(btnRetry); resultPanel.add(btnExit);
        add(resultPanel);

        setVisible(true);
    }

    private void calculateBMI() {
        try {
            double weight = Double.parseDouble(wTxt.getText().trim());
            double height = Double.parseDouble(hTxt.getText().trim());
            double bmi = rMetric.isSelected() ? weight / Math.pow(height / 100.0, 2) : 703 * (weight / Math.pow(height, 2));

            String status = "Obese";
            if (bmi < 18.5) status = "Underweight";
            else if (bmi < 25.0) status = "Normal weight";
            else if (bmi < 30.0) status = "Overweight";

            lblResult.setText("Your BMI is : " + String.format("%.2f", bmi));
            lblCat.setText("Category : " + status);

            inputPanel.setVisible(false);
            resultPanel.setVisible(true);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid Inputs! Please enter numbers.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(BMICalculatorApp::new);
    }
}
